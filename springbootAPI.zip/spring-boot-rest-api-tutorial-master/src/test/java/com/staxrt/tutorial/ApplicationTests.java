package com.staxrt.tutorial;

import com.staxrt.tutorial.model.Employee;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.*;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class ApplicationTests {

	@Autowired
	private TestRestTemplate restTemplate;

	@LocalServerPort
	private int port;

	private String getRootUrl() {
		return "http://localhost:" + port;
	}

	@Test
	public void contextLoads() {
	}

	@Test
	public void testGetAllUsers() {
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);

		ResponseEntity<String> response = restTemplate.exchange(getRootUrl() + "/users",
				HttpMethod.GET, entity, String.class);

		Assert.assertNotNull(response.getBody());
	}

	@Test
	public void testGetUserById() {
		Employee user = restTemplate.getForObject(getRootUrl() + "/users/1", Employee.class);
		System.out.println(user.getemployeeFirstName());
		Assert.assertNotNull(user);
	}

	@Test
	public void testCreateUser() {
		Employee user = new Employee();
		user.setemployeeId(10001);
		user.setemployeeFirstName("Rahul");
		user.setemployeeLastName("Raman");
		user.setcurrentDepartment("billing");
		user.setsalaryHistory(30000);



		ResponseEntity<Employee> postResponse = restTemplate.postForEntity(getRootUrl() + "/users", user, Employee.class);
		Assert.assertNotNull(postResponse);
		Assert.assertNotNull(postResponse.getBody());
	}

	@Test
	public void testUpdatePost() {
		int id = 10001;
		Employee user = restTemplate.getForObject(getRootUrl() + "/users/" + id, Employee.class);
		user.setemployeeFirstName("Rahul1");
		user.setemployeeLastName("Raman1");

		restTemplate.put(getRootUrl() + "/users/" + id, user);

		Employee updatedUser = restTemplate.getForObject(getRootUrl() + "/users/" + id, Employee.class);
		Assert.assertNotNull(updatedUser);
	}

}
