
package com.staxrt.tutorial.model;
import javax.persistence.*;


@Entity
@Table(name = "employee")
public class Employee {

    @Id
    @Column(name = "employeeId", nullable = false)
    private int employeeId;

    @Column(name = "employeeFirstName")
    private String employeeFirstName;

    @Column(name = "employeeLastName")
    private String employeeLastName;

    @Column(name = "currentDepartment")
    private String currentDepartment;
    
    @Column(name = "salaryHistory")
    private double salaryHistory;

    
    
	/*
	 * public Employee() { super(); }
	 * 
	 * public Employee (int employeeId, String employeeFirstName, String
	 * employeeLastName, String currentDepartment, double salaryHistory ) { super();
	 * this.employeeId = employeeId; this.employeeFirstName =employeeFirstName;
	 * this.employeeLastName = employeeFirstName; this.currentDepartment =
	 * currentDepartment; this.salaryHistory = salaryHistory; }
	 */


  public int getemployeeId() {
        return employeeId;
    }

  public void setemployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

  public String getemployeeFirstName() {
        return employeeFirstName;
    }


  public void setemployeeFirstName(String employeeFirstName) {
        this.employeeFirstName = employeeFirstName;
    }


  public String getemployeeLastName() {
        return employeeLastName;
    }


  public void setemployeeLastName(String employeeLastName) {
        this.employeeLastName = employeeLastName;
    }


  public String getcurrentDepartment() {
        return currentDepartment;
    }

  public void setcurrentDepartment(String currentDepartment) {
        this.currentDepartment = currentDepartment;
    }

  
  
  
  public double getsalaryHistory() {
      return salaryHistory;
  }


public void setsalaryHistory(double salaryHistory) {
      this.salaryHistory = salaryHistory;
  }


    @Override
    public String toString() {
        return "User{" +
                "employeeId" + employeeId +
                ", employeeFirstName='" + employeeFirstName + '\'' +
                ", employeeLastName='" + employeeLastName + '\'' +
                ", currentDepartment='" + currentDepartment + '\'' +
                ", salaryHistory='" + salaryHistory + '\'' +
                '}';
    }


}
