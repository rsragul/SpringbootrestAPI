package com.staxrt.tutorial.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.type.StringNVarcharType;

@Entity
@Table(name = "token1")
public class Token {

    @Id
    @Column(name = "tokenId", nullable = false)
    private String tokenId;

    @Column(name = "userId")
    private String userId;
              
 
  public String gettokenId() {
        return tokenId;
    }

  public void settokenId(String tokenId) {
        this.tokenId = tokenId;
    }

  public String getuserId() {
        return userId;
    }

  public void setuserId(String userId) {
        this.userId = userId;
    }


    @Override
    public String toString() {
        return "User{" +
                "tokenId" + tokenId +
                ", userId='" + userId + '\'' +              
                '}';
    }


}
