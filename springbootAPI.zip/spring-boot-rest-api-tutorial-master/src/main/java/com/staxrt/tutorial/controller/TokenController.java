package com.staxrt.tutorial.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.hibernate.type.StringNVarcharType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.staxrt.tutorial.exception.ResourceNotFoundException;
import com.staxrt.tutorial.model.Token;
import com.staxrt.tutorial.repository.TokenRepository;

@RestController
public class TokenController {

  @Autowired
  private TokenRepository tokenRepository;

  /**
   * Get all users list.
   *
   * @return the list
   */
  @GetMapping("/tokens")
  public List<Token> getAllUsers() {
    return tokenRepository.findAll();
  }

  
  @GetMapping("/tokens/{id}")
  public ResponseEntity<Token> getUsersById(@PathVariable(value = "id") String userId)
      throws ResourceNotFoundException {
	  Token user =
    		tokenRepository
            .findById(userId)
            .orElseThrow(() -> new ResourceNotFoundException("User not found on :: " + userId));
    return ResponseEntity.ok().body(user);
  }


  @PostMapping("/tokens")
  public Token createUser(@Valid @RequestBody Token user) {
    return tokenRepository.save(user);
  }


  @PutMapping("/tokens/{id}")
  public ResponseEntity<Token> updateUser(
      @PathVariable(value = "id") String userId, @Valid @RequestBody Token userDetails)
      throws ResourceNotFoundException {

    Token user =
    		tokenRepository
            .findById(userId)
            .orElseThrow(() -> new ResourceNotFoundException("User not found on :: " + userId));

    user.settokenId(userDetails.gettokenId());
    user.setuserId(userDetails.getuserId());
    final Token updatedUser = tokenRepository.save(user);
    return ResponseEntity.ok(updatedUser);
  }

}
