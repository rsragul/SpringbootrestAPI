package com.staxrt.tutorial.repository;

import com.staxrt.tutorial.model.Token;

import org.hibernate.type.StringNVarcharType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface TokenRepository extends JpaRepository<Token, String> {
	
}
