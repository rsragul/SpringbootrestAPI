package com.staxrt.tutorial.controller;

import java.io.Console;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.staxrt.tutorial.exception.ResourceNotFoundException;
import com.staxrt.tutorial.model.Employee;
import com.staxrt.tutorial.model.Token;
import com.staxrt.tutorial.repository.EmployeeRepository;
import com.staxrt.tutorial.repository.TokenRepository;

@RestController
public class EmployeeController {

  @Autowired
  private EmployeeRepository employeeRepository;
  
  @Autowired
  private TokenRepository TokenRepository;

  /**
   * Get all users list.
   *
   * @return the list
   */
  @GetMapping("/users")
  public List<Employee> getAllUsers() {
    return employeeRepository.findAll();
  }

  
  @GetMapping("/users/{id}")
  public ResponseEntity<Employee> getUsersById(@RequestHeader("authorization") String requestToken, @PathVariable(value = "id") String userId)
      throws Exception {
	  List<Token> tokens = TokenRepository.findAll();
	  boolean isAuthorized = false;	  
    Employee user =
        employeeRepository
            .findById(Integer.parseInt(userId))
            .orElseThrow(() -> new ResourceNotFoundException("User not found on :: " + userId));
    for(int i=0; i< tokens.size(); i++) {
    	if(tokens.get(i).gettokenId().equals(requestToken)) {
    		if(tokens.get(i).getuserId().equals(userId) || tokens.get(i).getuserId().equals("Any")) {
    			isAuthorized = true;
    		}
    	}
    }
    if(isAuthorized) {
	    return ResponseEntity.ok().body(user);
    }
    else {
    	throw new Exception("Unauthorized request");
    }
    //return ResponseEntity..body(user);
  }


  @PostMapping("/users")
  public Employee createUser(@Valid @RequestBody Employee user) {
    return employeeRepository.save(user);
  }


  @PutMapping("/users/{id}")
  public ResponseEntity<Employee> updateUser(
      @PathVariable(value = "id") Integer userId, @Valid @RequestBody Employee userDetails)
      throws ResourceNotFoundException {

    Employee user =
        employeeRepository
            .findById(userId)
            .orElseThrow(() -> new ResourceNotFoundException("User not found on :: " + userId));

    user.setemployeeFirstName(userDetails.getemployeeFirstName());
    user.setemployeeFirstName(userDetails.getemployeeFirstName());
    final Employee updatedUser = employeeRepository.save(user);
    return ResponseEntity.ok(updatedUser);
  }


  @DeleteMapping("/user/{id}")
  public Map<String, Boolean> deleteUser(@PathVariable(value = "id") Integer userId) throws Exception {
    Employee user =
        employeeRepository
            .findById(userId)
            .orElseThrow(() -> new ResourceNotFoundException("User not found on :: " + userId));

    employeeRepository.delete(user);
    Map<String, Boolean> response = new HashMap<>();
    response.put("deleted", Boolean.TRUE);
    return response;
  }
}
